package com.floristeria.model.domain;

public class Floristeria {
	private String nom;
	
	public Floristeria(String nom) {
		this.nom = nom;
	}
	
	public String toString() {
		return "Nom floristeria: " + nom;
	}
	

}
