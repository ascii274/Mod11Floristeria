package com.floristeria.model.domain;

public enum TipusMaterial {
	FUSTA, PLASTIC;
	
}
